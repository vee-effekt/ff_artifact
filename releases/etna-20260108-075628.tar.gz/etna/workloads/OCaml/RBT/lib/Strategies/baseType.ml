open Type

type t = rbt [@@deriving sexp, quickcheck]
