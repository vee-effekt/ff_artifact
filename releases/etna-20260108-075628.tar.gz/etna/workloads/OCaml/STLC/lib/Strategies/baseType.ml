open Type_defn;;

type t = expr [@@deriving sexp, quickcheck]