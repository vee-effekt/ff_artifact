
jq -s 'flatten' experiments/coq-experiments/proplang/ShallowVsDeep/results/*.json > all-shallow-vs-deep-coq.json