# Ultra-Lightweight ETNA for Debugging

This is meant for finding edge cases for debugging other ETNA workloads. Everything, such as applying mutations and running the tests, should be done manually.