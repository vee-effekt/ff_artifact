special = ['BST,delete_5,prop_DeleteDelete',
           'BST,insert_3,prop_InsertInsert',
           'BST,union_8,prop_UnionPost']