Fast handwritten generators, using latest JS features. Build with 5.2.0+flambda2.

Requires [unboxed_splitmix](https://github.com/alpha-convert/unboxed-splitmix/tree/main).
Run `opam pin add unboxed_splitmix https://github.com/alpha-convert/unboxed-splitmix.git` before building.