# 🖊 ppx-template
> An opinionated GitHub template for OCaml PPX extensions 🐪

This is the starter template for an OCaml PPX, a macro extension for the OCaml language that rewrites the OCaml parsetree, similar to Rust macros. 
