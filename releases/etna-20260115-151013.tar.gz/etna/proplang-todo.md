Todo List


- [ ] Perl scripts are not working uniformly in Mac and Linux. Need to fix it. 