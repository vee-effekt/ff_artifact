
To compile, run `sbt`.

To run benchmarks, `sbt jmh:run`.