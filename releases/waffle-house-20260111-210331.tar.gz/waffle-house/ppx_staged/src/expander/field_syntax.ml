open! Import
include Field_syntax_intf

module Tuple = struct
  type ast = core_type
  type t = ast

  let create = Fn.id
  let location t = t.ptyp_loc
  let core_type t = t
  let pattern _ ~loc pat_list = ppat_tuple ~loc pat_list
  (*let expression _ ~loc expr_list = pexp_tuple ~loc expr_list*)
  let expression _ ~loc expr_list =
    let quoted = List.map ~f:(fun x -> [%expr .~[%e x]]) expr_list in 
    [%expr .< [%e pexp_tuple ~loc quoted ] >. ]
  end

module Record = struct
  type ast = label_declaration
  type t = ast

  let create ast = ast
  let location t = t.pld_loc
  let core_type t = t.pld_type

  let pattern list ~loc pat_list =
    let alist =
      List.map2_exn list pat_list ~f:(fun t pat -> lident_loc t.pld_name, pat)
    in
    ppat_record ~loc alist Closed
  ;;

  let expression list ~loc expr_list =
    let alist =
      List.map2_exn list expr_list ~f:(fun t expr -> lident_loc t.pld_name, [%expr .~[%e expr]])
    in
    [%expr .< [%e pexp_record ~loc alist None ] >. ]
  ;;
end
