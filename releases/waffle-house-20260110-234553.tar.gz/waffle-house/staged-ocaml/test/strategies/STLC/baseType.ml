open Type;;

type t = expr [@@deriving sexp, quickcheck]