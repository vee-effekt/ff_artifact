package RBT

val rbt_type_limits = Int.MaxValue