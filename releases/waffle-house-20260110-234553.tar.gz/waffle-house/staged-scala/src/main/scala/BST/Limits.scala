package BST

val bst_bespoke_limits = Int.MaxValue
val bst_type_limits = Int.MaxValue