let bst_bespoke_limits = 1000
let rbt_bespoke_limits = 1000
let stlc_bespoke_limits = 1000

let stlc_type_limits = 10
let rbt_type_limits = 50
let bst_type_limits = 100